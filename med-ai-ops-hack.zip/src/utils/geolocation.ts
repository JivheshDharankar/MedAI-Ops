import { Hospital } from '@/types/hospital';

export function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export interface NearbyHospital extends Hospital {
  distance: number;
  mapsUrl: string;
}

export function findNearestHospitals(
  userLat: number,
  userLng: number,
  hospitals: Hospital[],
  limit: number = 3
): NearbyHospital[] {
  return hospitals
    .map(h => ({
      ...h,
      distance: distanceKm(userLat, userLng, h.lat, h.lng),
      mapsUrl: `https://www.google.com/maps/dir/?api=1&destination=${h.lat},${h.lng}`,
    }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, limit);
}
